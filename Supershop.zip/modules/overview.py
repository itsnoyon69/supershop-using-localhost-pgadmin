import streamlit as st
import pandas as pd
import plotly.express as px

def show_overview(df):

    st.markdown("## 📊 Business Overview")

    # ================= KPI =================
    total_revenue = df['total_price'].sum()
    total_orders = df['order_id'].nunique()
    total_customers = df['customer_id'].nunique()
    avg_order = total_revenue / total_orders if total_orders != 0 else 0

    import pandas as pd
    from db import get_conn

    # ================= LATEST CUSTOMER =================
    cust_df = pd.read_sql("SELECT * FROM customers", get_conn())

    with st.expander("👥 View Latest Customers"):

        st.dataframe(
            cust_df.sort_values(by='customer_id', ascending=False).head(10),
            use_container_width=True
        )

    col1, col2, col3, col4 = st.columns(4)

    col1.metric("💰 Revenue", f"{total_revenue:,.0f}")
    col2.metric("📦 Orders", total_orders)
    col3.metric("👥 Customers", total_customers)
    col4.metric("🛍 Avg Order", f"{avg_order:,.0f}")

    st.markdown("---")

    # ================= SALES TREND =================
    st.subheader("📈 Sales Trend")

    sales = df.groupby('order_date')['total_price'].sum().reset_index()

    fig = px.line(
        sales,
        x='order_date',
        y='total_price',
        markers=True
    )

    st.plotly_chart(fig, use_container_width=True)

    st.markdown("---")

    # ================= SMART INSIGHT =================
    st.subheader("🧠 Smart Insight")

    product_perf = df.groupby('product_name')['quantity'].sum()

    top_product = product_perf.idxmax()
    low_product = product_perf.idxmin()

    trend = sales['total_price'].iloc[-1] - sales['total_price'].iloc[0]

    col1, col2 = st.columns(2)

    with col1:
        if trend > 0:
            st.success("📈 Sales is growing")
        else:
            st.warning("📉 Sales is declining")

    with col2:
        st.info(f"🔥 Top Product: {top_product}")

    st.write(f"⚠️ Low Product: {low_product}")
    st.write(f"🎯 Action: Bundle '{low_product}' with '{top_product}'")

    st.markdown("---")

    # ================= MINI PRODUCT SNAPSHOT =================
    st.subheader("📦 Quick Product View")

    top5 = product_perf.sort_values(ascending=False).head(5)

    st.bar_chart(top5)

    st.markdown("---")