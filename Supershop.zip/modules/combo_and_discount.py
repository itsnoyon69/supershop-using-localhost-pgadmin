import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import random

from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler


# =========================================================
# SMART COMBO + DISCOUNT AI
# =========================================================
def show_combo_engine(df):

    st.markdown("## 🤖 Business Optimization Engine")

    # =====================================================
    # SESSION STATE
    # =====================================================
    if "combo_history" not in st.session_state:
        st.session_state.combo_history = []

    if "discount_history" not in st.session_state:
        st.session_state.discount_history = []

    if "ai_history" not in st.session_state:
        st.session_state.ai_history = []

    if "ai_combo_result" not in st.session_state:
        st.session_state.ai_combo_result = None

    if "ai_discount_result" not in st.session_state:
        st.session_state.ai_discount_result = None

    # =====================================================
    # PRODUCT DATA
    # =====================================================
    product_df = df.groupby('product_name').agg({
        'quantity': 'sum',
        'total_price': 'sum',
        'order_id': 'nunique',
        'customer_id': 'nunique'
    }).reset_index()

    product_df.columns = [
        'product_name',
        'sales',
        'revenue',
        'orders',
        'customers'
    ]

    # =====================================================
    # CLEAN
    # =====================================================
    product_df = product_df.replace(
        [np.inf, -np.inf],
        0
    ).fillna(0)

    # =====================================================
    # ML FEATURES
    # =====================================================
    features = product_df[[
        'sales',
        'revenue',
        'orders',
        'customers'
    ]]

    scaler = StandardScaler()

    scaled = scaler.fit_transform(features)

    # =====================================================
    # ML MODEL
    # =====================================================
    model = KMeans(
        n_clusters=3,
        random_state=42,
        n_init=10
    )

    product_df['cluster'] = model.fit_predict(
        scaled
    )

    # =====================================================
    # LABELS
    # =====================================================
    cluster_sales = product_df.groupby(
        'cluster'
    )['sales'].mean()

    high_cluster = cluster_sales.idxmax()
    low_cluster = cluster_sales.idxmin()

    def cluster_label(c):

        if c == high_cluster:
            return "🔥 High Demand"

        elif c == low_cluster:
            return "⚠️ Weak Demand"

        else:
            return "📈 Moderate"

    product_df['status'] = product_df[
        'cluster'
    ].apply(cluster_label)

    # =====================================================
    # REUSABLE ML FUNCTION
    # =====================================================
    def calculate_combo_metrics(p1, p2):

        score1 = (
            p1['sales'] /
            product_df['sales'].max()
        ) * 100

        score2 = (
            p2['sales'] /
            product_df['sales'].max()
        ) * 100

        combo_score = (
            score1 * 0.5 +
            score2 * 0.5
        )

        combo_score = max(
            30,
            min(95, combo_score)
        )

        expected_growth = (
            combo_score / 100
        ) * 25

        current_revenue = (
            p1['revenue'] +
            p2['revenue']
        )

        predicted_revenue = (
            current_revenue *
            (1 + expected_growth / 100)
        )

        return (
            combo_score,
            expected_growth,
            current_revenue,
            predicted_revenue
        )

    # =====================================================
    # TABS
    # =====================================================
    tab1, tab2, tab3 = st.tabs([
        "🎁 Combo Simulator",
        "💸 Discount Simulator",
        "🤖 AI Suggestion"
    ])

    # =====================================================
    # 1️⃣ COMBO SIMULATOR
    # =====================================================
    with tab1:

        st.subheader("🎁 Smart Combo Simulator")

        col1, col2 = st.columns(2)

        with col1:

            product1 = st.selectbox(
                "Select Product A",
                product_df['product_name'].unique(),
                key="combo_product_1"
            )

        with col2:

            product2 = st.selectbox(
                "Select Product B",
                product_df['product_name'].unique(),
                key="combo_product_2"
            )

        p1 = product_df[
            product_df['product_name'] == product1
        ].iloc[0]

        p2 = product_df[
            product_df['product_name'] == product2
        ].iloc[0]

        (
            combo_score,
            expected_growth,
            current_revenue,
            predicted_revenue
        ) = calculate_combo_metrics(
            p1,
            p2
        )

        # =================================================
        # OUTPUT
        # =================================================
        c1, c2, c3 = st.columns(3)

        c1.metric(
            "Success Rate",
            f"{combo_score:.1f}%"
        )

        c2.metric(
            "Expected Growth",
            f"{expected_growth:.1f}%"
        )

        c3.metric(
            "Predicted Revenue",
            f"{predicted_revenue:.0f}"
        )

        st.markdown("---")

        # =================================================
        # RESULT
        # =================================================
        if combo_score >= 80:

            st.success("🔥 High Success Combo")

        elif combo_score >= 60:

            st.info("📈 Moderate Combo")

        else:

            st.error("⚠️ Weak Combo Match")

        # =================================================
        # SAVE
        # =================================================
        if st.button(
            "💾 Save Combo",
            key=f"save_combo_{product1}_{product2}"
        ):

            combo_data = {
                "Type": "Combo",
                "Product A": product1,
                "Product B": product2,
                "Success Rate": round(combo_score, 1),
                "Growth": round(expected_growth, 1),
                "Revenue": round(predicted_revenue, 0)
            }

            st.session_state.combo_history.append(
                combo_data
            )

            st.success("✅ Combo saved")

        # =================================================
        # GRAPH
        # =================================================
        graph_df = pd.DataFrame({
            'Metric': [
                'Current Revenue',
                'Predicted Revenue'
            ],
            'Value': [
                current_revenue,
                predicted_revenue
            ]
        })

        fig = px.bar(
            graph_df,
            x='Metric',
            y='Value',
            title="Combo Revenue Prediction"
        )

        st.plotly_chart(
            fig,
            use_container_width=True
        )

    # =====================================================
    # 2️⃣ DISCOUNT SIMULATOR
    # =====================================================
    with tab2:

        st.subheader("💸 Smart Discount Simulator")

        selected_product = st.selectbox(
            "Select Product",
            product_df['product_name'].unique(),
            key="discount_product"
        )

        discount = st.slider(
            "Discount %",
            0,
            70,
            15,
            key="discount_slider"
        )

        row = product_df[
            product_df['product_name'] ==
            selected_product
        ].iloc[0]

        current_sales = row['sales']

        current_revenue = row['revenue']

        demand_boost = (
            discount * 1.3
        )

        future_sales = (
            current_sales *
            (1 + demand_boost / 100)
        )

        discounted_revenue = (
            current_revenue *
            (1 - discount / 100)
        )

        future_revenue = (
            discounted_revenue *
            (1 + demand_boost / 100)
        )

        revenue_change = (
            (
                future_revenue -
                current_revenue
            ) /
            current_revenue
        ) * 100

        # =================================================
        # OUTPUT
        # =================================================
        d1, d2, d3 = st.columns(3)

        d1.metric(
            "Future Sales",
            f"{future_sales:.0f}"
        )

        d2.metric(
            "Revenue Impact",
            f"{revenue_change:.2f}%"
        )

        d3.metric(
            "Demand Boost",
            f"{demand_boost:.1f}%"
        )

        st.markdown("---")

        if revenue_change > 10:

            st.success("🚀 Strong Discount Strategy")

        elif revenue_change > 0:

            st.info("📈 Moderate Discount Strategy")

        else:

            st.error("⚠️ Discount Risk")

        # =================================================
        # SAVE
        # =================================================
        if st.button(
            "💾 Save Discount Strategy",
            key=f"save_discount_{selected_product}_{discount}"
        ):

            discount_data = {
                "Type": "Discount",
                "Product": selected_product,
                "Discount %": discount,
                "Revenue Impact": round(revenue_change, 2),
                "Future Sales": round(future_sales, 0)
            }

            st.session_state.discount_history.append(
                discount_data
            )

            st.success("✅ Discount strategy saved")

    # =====================================================
    # 3️⃣ AI SUGGESTION
    # =====================================================
    with tab3:

        st.subheader("🤖 AI Combo + Discount Suggestion")

        # =================================================
        # AI COMBO
        # =================================================
        if st.button(
            "🎲 Generate AI Combo",
            key="generate_ai_combo_btn"
        ):

            high_products = product_df[
                product_df['status'] ==
                "🔥 High Demand"
            ]

            weak_products = product_df[
                product_df['status'] ==
                "⚠️ Weak Demand"
            ]

            weak = weak_products.sample(
                n=1
            ).iloc[0]

            strong = high_products.sample(
                n=1
            ).iloc[0]

            while weak['product_name'] == strong['product_name']:

                strong = high_products.sample(
                    n=1
                ).iloc[0]

            (
                ai_score,
                ai_growth,
                current_revenue,
                future_revenue
            ) = calculate_combo_metrics(
                weak,
                strong
            )

            st.session_state.ai_combo_result = {
                "Product A": weak['product_name'],
                "Product B": strong['product_name'],
                "Success": round(ai_score, 1),
                "Growth": round(ai_growth, 1),
                "Revenue": round(future_revenue, 0)
            }

        # =================================================
        # SHOW AI COMBO
        # =================================================
        if st.session_state.ai_combo_result is not None:

            result = st.session_state.ai_combo_result

            st.success(f"""
            🎁 AI Suggested Combo

            Product A: {result['Product A']}
            Product B: {result['Product B']}
            """)

            c1, c2, c3 = st.columns(3)

            c1.metric(
                "Success Rate",
                f"{result['Success']}%"
            )

            c2.metric(
                "Growth",
                f"{result['Growth']}%"
            )

            c3.metric(
                "Revenue",
                f"{result['Revenue']}"
            )

            if st.button(
                "💾 Save AI Combo",
                key="save_ai_combo_btn"
            ):

                save_data = {
                    "Type": "AI Combo",
                    **result
                }

                st.session_state.ai_history.append(
                    save_data
                )

                st.success("✅ AI Combo saved")

        st.markdown("---")

        # =================================================
        # AI DISCOUNT
        # =================================================
        if st.button(
            "🎲 Generate AI Discount",
            key="generate_ai_discount_btn"
        ):

            weak_products = product_df[
                product_df['status'] ==
                "⚠️ Weak Demand"
            ]

            product = weak_products.sample(
                n=1
            ).iloc[0]

            suggested_discount = random.randint(
                10,
                40
            )

            demand_growth = (
                suggested_discount * 1.3
            )

            future_revenue = (
                product['revenue'] *
                (
                    1 +
                    demand_growth / 100
                )
            )

            st.session_state.ai_discount_result = {
                "Product": product['product_name'],
                "Discount": suggested_discount,
                "Growth": round(demand_growth, 1),
                "Revenue": round(future_revenue, 0)
            }

        # =================================================
        # SHOW AI DISCOUNT
        # =================================================
        if st.session_state.ai_discount_result is not None:

            discount_result = st.session_state.ai_discount_result

            st.info(f"""
            💸 AI Discount Suggestion

            Product: {discount_result['Product']}
            """)

            d1, d2, d3 = st.columns(3)

            d1.metric(
                "Suggested Discount",
                f"{discount_result['Discount']}%"
            )

            d2.metric(
                "Expected Growth",
                f"{discount_result['Growth']}%"
            )

            d3.metric(
                "Future Revenue",
                f"{discount_result['Revenue']}"
            )

            if st.button(
                "💾 Save AI Discount",
                key="save_ai_discount_btn"
            ):

                save_discount = {
                    "Type": "AI Discount",
                    **discount_result
                }

                st.session_state.ai_history.append(
                    save_discount
                )

                st.success("✅ AI Discount saved")

    # =====================================================
    # HISTORY
    # =====================================================
    st.markdown("---")

    st.subheader("🕘 Strategy History")

    all_history = (
        st.session_state.combo_history +
        st.session_state.discount_history +
        st.session_state.ai_history
    )

    if len(all_history) > 0:

        history_df = pd.DataFrame(
            all_history
        )

        st.dataframe(
            history_df,
            use_container_width=True
        )

    else:

        st.info("No strategy history yet")