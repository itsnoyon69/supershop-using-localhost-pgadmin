import streamlit as st
import pandas as pd
from db import get_conn

def show_kpi(df):

    cust_df = pd.read_sql("SELECT * FROM customers", get_conn())

    col1, col2, col3 = st.columns(3)

    col1.metric("💰 Revenue", f"{df['total_price'].sum():,.0f}")
    col2.metric("📦 Orders", df['order_id'].nunique())
    col3.metric("👥 Customers", cust_df['customer_id'].nunique())

    st.subheader("🧾 Latest Customers")
    st.dataframe(cust_df.tail(5))